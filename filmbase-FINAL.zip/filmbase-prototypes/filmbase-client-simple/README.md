# filmbase-client-simple

Filmbase single-page application web client built with Vue. Filmbase provides information about films and allows users to add films, edit films, and delete films.
