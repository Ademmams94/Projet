import './assets/styles/main.css'; // Chemin de votre fichier CSS principal
import { createApp } from 'vue';
import { createPinia } from 'pinia';
import App from './App.vue';
import router from './router';

const app = createApp(App);
const pinia = createPinia();

app.use(pinia);
app.use(router);

// Initialiser le store d'authentification
const authStore = pinia.useAuthStore || null;
if (authStore) authStore().initialize();

app.mount('#app');
