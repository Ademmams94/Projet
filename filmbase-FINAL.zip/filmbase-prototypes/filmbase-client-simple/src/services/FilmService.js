import axios from 'axios';
import validator from '../validation/FilmValidator.js';

const API_BASE_URL = 'http://localhost:5001/api'; // Backend URL

// Récupérer tous les films depuis le backend uniquement
async function getAllFilms(query) {
  try {
    const response = await axios.get(`${API_BASE_URL}/films`);
    const backendFilms = response.data;

    if (query) {
      query = normalizeString(query);
      return backendFilms.filter(
        (film) =>
          filmTitleMatchesQuery(film, query) ||
          filmDirectorMatchesQuery(film, query)
      );
    }

    return backendFilms;
  } catch (error) {
    console.error('Erreur lors de la récupération des films :', error);
    throw new Error('Impossible de récupérer les films.');
  }
}

// Ajouter un film dans le backend
async function createFilm(title, director, year, duration, description) {
  const error = validator.validate(title, director, year, duration, description);
  if (error) {
    throw new Error(`Failed to create film due to invalid properties: ${error}`);
  }

  try {
    const token = localStorage.getItem('token'); // Récupérer le token JWT
    const response = await axios.post(
      `${API_BASE_URL}/films`,
      { title, director, year, duration, description },
      {
        headers: {
          Authorization: `Bearer ${token}`, // Ajouter l'en-tête Authorization
        },
      }
    );

    return response.data; // Retourner le film ajouté
  } catch (error) {
    console.error("Erreur lors de l'ajout du film :", error);
    throw new Error("Failed to create film.");
  }
}

// Trouver un film par ID depuis le backend
async function findFilm(id) {
  try {
    const response = await axios.get(`${API_BASE_URL}/films/${id}`);
    return response.data; // Retourner les détails du film
  } catch (error) {
    console.error("Erreur lors de la récupération du film :", error);
    throw new Error("Film not found.");
  }
}

// Supprimer un film depuis le backend
async function deleteFilm(id) {
  try {
    const token = localStorage.getItem('token'); // Récupérer le token JWT
    if (!token) {
      throw new Error("Authorization token not found.");
    }

    await axios.delete(`${API_BASE_URL}/films/${id}`, {
      headers: {
        Authorization: `Bearer ${token}`, // Ajouter l'en-tête Authorization
      },
    });

    return true; // Suppression réussie
  } catch (error) {
    console.error("Erreur lors de la suppression du film :", error);
    throw new Error("Failed to delete film.");
  }
}
// Mettre à jour un film existant dans le backend
async function updateFilm(id, title, director, year, duration, description) {
  const error = validator.validate(title, director, year, duration, description);
  if (error) {
    throw new Error(`Failed to update film due to invalid properties: ${error}`);
  }

  try {
    const token = localStorage.getItem('token'); // Récupérer le token JWT
    if (!token) {
      throw new Error("Authorization token not found.");
    }

    await axios.put(
      `${API_BASE_URL}/films/${id}`,
      { title, director, year, duration, description },
      {
        headers: {
          Authorization: `Bearer ${token}`, // Ajouter l'en-tête Authorization
        },
      }
    );

    return true; // Mise à jour réussie
  } catch (error) {
    console.error("Erreur lors de la mise à jour du film :", error);
    throw new Error("Failed to update film.");
  }
}


// Rechercher des films dans la base de données
async function searchFilms(query) {
  if (!query) return []; // Retourner une liste vide si aucune recherche

  try {
    const response = await axios.get(`${API_BASE_URL}/films/search`, {
      params: { q: query }, // Envoie le paramètre de recherche au backend
    });
    return response.data; // Retourner les résultats
  } catch (error) {
    console.error("Erreur lors de la recherche des films :", error);
    throw new Error("Impossible de rechercher les films.");
  }
}

// Helpers pour la recherche
function filmTitleMatchesQuery(film, query) {
  return film && film.title
    ? normalizeString(film.title).includes(query)
    : false;
}

function filmDirectorMatchesQuery(film, query) {
  return film && film.director
    ? normalizeString(film.director).includes(query)
    : false;
}

function normalizeString(string) {
  if (!string) return '';
  return string
    .trim()
    .replace(/\s+/g, ' ')
    .toLowerCase()
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '');
}

// Expose les fonctions
export default function useFilmService() {
  return {
    getAllFilms,
    createFilm,
    findFilm,
    deleteFilm,
    updateFilm, // Inclure la fonction de suppression
    searchFilms, // Inclure la recherche
  };
}
