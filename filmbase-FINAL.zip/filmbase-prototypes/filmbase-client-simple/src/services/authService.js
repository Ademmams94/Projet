import axios from "axios";

const API_BASE_URL = "http://localhost:5001/api";

export default {
  async login(email, password) {
    try {
      const response = await axios.post(`${API_BASE_URL}/login`, {
        email,
        password,
      });

      // Stocker le token JWT
      localStorage.setItem("token", response.data.token);

      return response.data; // Retourner l'utilisateur et le token
    } catch (error) {
      console.error("Login error:", error);
      throw new Error(error.response?.data?.message || "Login failed");
    }
  },

  async register(username, email, password) {
    try {
      console.log("Sending registration data:", { username, email, password });
      const response = await axios.post(`${API_BASE_URL}/register`, {
        username,
        email,
        password,
      });
  
      console.log("Registration response:", response.data);
      return response.data; // Retourner la réponse du backend
    } catch (error) {
      console.error("Registration error:", error.response?.data || error.message);
      throw new Error(error.response?.data?.message || "Registration failed");
    }
  },

  logout() {
    localStorage.removeItem("token"); // Supprimer le token
  },

  getToken() {
    return localStorage.getItem("token"); // Récupérer le token
  },
};
