<script setup>
import { RouterView } from 'vue-router'
import PageHeader from './components/PageHeader.vue'
import PageFooter from './components/PageFooter.vue'
</script>

<template>
  <div id="app">
    <PageHeader />
    <main>
      <RouterView />
    </main>
    <PageFooter />
  </div>
</template>


<style>
/* Appliquez les styles mis à jour ici */
html,
body {
  height: 100%;
  margin: 0;
}

#app {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

#app > header,
#app > footer {
  padding: var(--padding-large);
}

#app > main {
  flex-grow: 1;
  padding: var(--padding-large);
}

.content {
  max-width: var(--max-width);
  margin: 0 auto;
}

.app-logo * {
  font-size: 1.5rem;
  font-weight: bold;
  color: var(--color-heading);
}

.app-logo a:link,
.app-logo a:visited {
  color: var(--color-heading);
}
</style>
