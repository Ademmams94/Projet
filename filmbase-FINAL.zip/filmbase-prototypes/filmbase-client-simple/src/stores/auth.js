import { defineStore } from 'pinia';

export const useAuthStore = defineStore('auth', {
  state: () => ({
    isAuthenticated: !!localStorage.getItem('token'), // Initialise en fonction du token
    token: localStorage.getItem('token') || null, // Sauvegarder le token
  }),
  actions: {
    initialize() {
      this.token = localStorage.getItem('token');
      this.isAuthenticated = !!this.token;
    },
    login(token) {
      localStorage.setItem('token', token);
      this.token = token;
      this.isAuthenticated = true;
    },
    logout() {
      localStorage.removeItem('token');
      this.token = null;
      this.isAuthenticated = false;
    },
  },
});
