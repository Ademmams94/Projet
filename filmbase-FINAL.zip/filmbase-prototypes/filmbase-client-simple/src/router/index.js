import { createRouter, createWebHistory } from "vue-router";
import authService from "../services/authService"; // Importer authService pour vérifier l'authentification
import HomePage from "../pages/HomePage.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      name: "home",
      component: HomePage,
    },
    {
      path: "/about",
      name: "about",
      component: () => import("../pages/AboutPage.vue"),
    },
    {
      path: "/films/add",
      name: "add",
      component: () => import("../pages/AddFilmPage.vue"),
      meta: { requiresAuth: true }, // Ajouter un méta-champ pour protéger cette route
    },
    {
      path: "/films/:id",
      name: "film",
      component: () => import("../pages/FilmPage.vue"),
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('../pages/login.vue'),
      props: (route) => ({ redirect: route.query.redirect || 'home' }), // Redirigez après le login
    },
    {
      path: "/register",
      name: "register",
      component: () => import("../pages/Register.vue"),
    },
  ],
  scrollBehavior: (to, from, savedPosition) => {
    if (savedPosition) {
      return savedPosition;
    } else {
      return { top: 0 };
    }
  },
});

// Ajouter un guard global pour protéger les routes nécessitant une authentification
router.beforeEach((to, from, next) => {
  if (to.meta.requiresAuth && !authService.getToken()) {
    // Afficher un message d'alerte si non connecté
    alert("You must be logged in to add a film!");
    next({ name: "login" }); // Rediriger vers la page login
  } else {
    next(); // Continuer la navigation
  }
});

export default router;
