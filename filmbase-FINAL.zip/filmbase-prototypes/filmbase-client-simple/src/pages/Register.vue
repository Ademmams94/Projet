<template>
  <div class="register-container">
    <h1 class="title">Register</h1>
    <form @submit.prevent="handleRegister" class="form">
      <div class="form-group">
        <input
          type="text"
          v-model="name"
          placeholder="Name"
          required
        />
      </div>
      <div class="form-group">
        <input
          type="email"
          v-model="email"
          placeholder="Email"
          required
        />
      </div>
      <div class="form-group">
        <input
          type="password"
          v-model="password"
          placeholder="Password"
          required
        />
      </div>
      <button type="submit" class="btn">Register</button>
    </form>
    <p class="login-link">
      Already have an account? <router-link to="/login">Login here</router-link>
    </p>
  </div>
</template>

<script>
import authService from "../services/authService.js";

export default {
  name: "Register",
  data() {
    return {
      name: "",
      email: "",
      password: "",
    };
  },
  methods: {
  async handleRegister() {
    try {
      const response = await authService.register(this.name, this.email, this.password);

      console.log("Registration successful:", response); // Log succès
      alert("Registration successful!");
      this.$router.push({ name: "login" }); // Redirection vers la page de login
    } catch (error) {
      console.error("Error during registration:", error.response?.data || error.message);
      alert(error.response?.data?.error || "Registration failed. Please try again.");
    }
  },
},
};
</script>

<style scoped>
.register-container {
  max-width: 400px;
  margin: 100px auto;
  padding: 20px;
  background-color: #1e1e1e;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  color: #ffffff;
}
.title {
  text-align: center;
  font-size: 24px;
  margin-bottom: 20px;
}
.form {
  display: flex;
  flex-direction: column;
  gap: 15px;
}
.form-group input {
  width: 100%;
  padding: 10px;
  border: 1px solid #444;
  border-radius: 4px;
  background-color: #2e2e2e;
  color: #fff;
  font-size: 14px;
}
.form-group input:focus {
  outline: none;
  border-color: #007bff;
}
.btn {
  padding: 10px;
  background-color: #28a745;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
  text-align: center;
}
.btn:hover {
  background-color: #218838;
}
.login-link {
  text-align: center;
  margin-top: 15px;
  font-size: 14px;
}
.login-link a {
  color: #007bff;
  text-decoration: none;
}
.login-link a:hover {
  text-decoration: underline;
}
</style>
