<script setup></script>

<template>
  <main>
    <div class="content">
      <h1>About Us</h1>
      <section class="intro">
        <p>
          Welcome to our platform! We are dedicated to providing you with the best online experience, offering a curated selection of content designed to inspire, educate, and entertain.
        </p>
      </section>

      <section class="mission">
        <h2>Our Mission</h2>
        <p>
          Our mission is to create a space where users can explore, learn, and connect with topics that matter. Whether you are here for education, entertainment, or curiosity, we strive to deliver high-quality content tailored to your needs.
        </p>
      </section>

      <section class="team">
        <h2>Meet Our Team</h2>
        <p>
          We are a passionate group of creators, developers, and innovators who are committed to making this platform the best it can be. Our team values creativity, collaboration, and excellence in everything we do.
        </p>
      </section>

      <section class="values">
        <h2>Our Core Values</h2>
        <ul>
          <li><strong>Integrity:</strong> We are transparent and honest in all our actions.</li>
          <li><strong>Innovation:</strong> We constantly look for new ways to improve and evolve.</li>
          <li><strong>Community:</strong> We prioritize building a welcoming and supportive environment.</li>
          <li><strong>Quality:</strong> We strive for excellence in all that we create and share.</li>
        </ul>
      </section>

      <section class="contact">
        <h2>Contact Us</h2>
        <p>
          Have questions or feedback? Feel free to reach out to us anytime at <a href="mailto:efrei@efrei.com">support@yourdomain.com</a>. We'd love to hear from you!
        </p>
      </section>
    </div>
  </main>
</template>

<style scoped>
main {
  font-family: Arial, sans-serif;
  line-height: 1.6;
  margin: 0 auto;
  padding: 20px;
  max-width: 800px;
}

.content {
  text-align: left;
}

h1 {
  text-align: center;
  color: #eadddd;
}

h2 {
  color: #9f9898;
  margin-top: 20px;
}

p {
  color: #a29e9e;
  margin: 10px 0;
}

ul {
  list-style-type: disc;
  margin-left: 20px;
  color: #949191;
}

a {
  color: #89a7c4;
  text-decoration: none;
}

a:hover {
  text-decoration: underline;
}
</style>
