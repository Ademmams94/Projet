<script setup>
import { ref, reactive, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import FilmHeader from '../components/FilmHeader.vue';
import FilmForm from '../components/FilmForm.vue';
import FilmbaseLogo from '../components/icons/FilmbaseLogo.vue';
import EditIcon from '../components/icons/EditIcon.vue';
import axios from 'axios';

const route = useRoute();
const router = useRouter();
const id = Number.parseInt(route.params.id);

const film = reactive({});
const formIsEnabled = ref(false);
const filmIsDeleted = ref(false);
const successMessage = ref('');
const errorMessage = ref('');
const loading = ref(true); // Indicateur de chargement

// Charger les données du film depuis l'API
async function fetchFilm() {
  loading.value = true;
  try {
    const response = await axios.get(`http://localhost:5001/api/films/${id}`);
    Object.assign(film, response.data); // Remplir l'objet réactif avec les données récupérées
  } catch (error) {
    console.error('Erreur lors de la récupération du film :', error.message);
    errorMessage.value = 'Film not found or an error occurred.';
  } finally {
    loading.value = false;
  }
}

// Supprimer un film via l'API (uniquement si l'utilisateur est connecté)
async function deleteFilm() {
  clearMessages();

  // Récupérer le token JWT
  const token = localStorage.getItem('token');
  if (!token) {
    errorMessage.value = 'You must be logged in to delete this film.';
    return;
  }

  try {
    await axios.delete(`http://localhost:5001/api/films/${id}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    filmIsDeleted.value = true;
    successMessage.value = 'Successfully deleted film.';
  } catch (error) {
    console.error('Erreur lors de la suppression du film :', error.message);
    errorMessage.value = 'Failed to delete film. Please try again.';
  }
}

// Modifier un film via l'API
async function saveFilm(title, director, year, duration, description) {
  clearMessages();

  // Valider les données
  title = title.trim();
  director = director.trim();
  description = description.trim();

  if (!title || !director || !year || !duration || !description) {
    errorMessage.value = 'All fields are required.';
    return;
  }

  // Récupérer le token JWT
  const token = localStorage.getItem('token');
  if (!token) {
    errorMessage.value = 'You must be logged in to edit this film.';
    return;
  }

  try {
    await axios.put(
      `http://localhost:5001/api/films/${id}`,
      { title, director, year: Number.parseInt(year), duration: Number.parseInt(duration), description },
      { headers: { Authorization: `Bearer ${token}` } }
    );

    // Mettre à jour localement les données du film
    Object.assign(film, { title, director, year, duration, description });
    successMessage.value = 'Successfully updated film.';
    formIsEnabled.value = false; // Désactiver le formulaire après mise à jour
  } catch (error) {
    console.error('Erreur lors de la modification du film :', error.message);
    errorMessage.value = 'Failed to update film. Please try again.';
  }
}

// Réinitialiser les messages
function clearMessages() {
  successMessage.value = '';
  errorMessage.value = '';
}

// Basculer le formulaire d'édition
function editFilm() {
  formIsEnabled.value = !formIsEnabled.value;
  if (!formIsEnabled.value) clearMessages();
}

// Charger les données au montage
onMounted(fetchFilm);
</script>

<template>
  <main>
    <!-- Chargement en cours -->
    <div v-if="loading" class="content center">
      <p>Loading film details...</p>
    </div>

    <!-- Film trouvé et non supprimé -->
    <div v-if="!loading && film && !filmIsDeleted" class="content">
      <FilmHeader :film="film" />
      <p>{{ film.description }}</p>
      <button @click="editFilm" class="edit"><EditIcon /></button>

      <FilmForm
        v-if="formIsEnabled"
        primary-button="Save"
        primary-button-class="success"
        secondary-button="Delete"
        secondary-button-class="danger"
        :film="film"
        :success-message="successMessage"
        :error-message="errorMessage"
        @primary-button-clicked="saveFilm"
        @secondary-button-clicked="deleteFilm"
      />
    </div>

    <!-- Film supprimé -->
    <div v-else-if="!loading && film && filmIsDeleted" class="content">
      <FilmHeader :film="film" />
      <p class="success">{{ successMessage }}</p>
      <p>
        <RouterLink :to="{ name: 'home' }" class="button home">
          <FilmbaseLogo />
          <span>Home</span>
        </RouterLink>
      </p>
    </div>

    <!-- Film non trouvé -->
    <div v-else-if="!loading && errorMessage" class="content center">
      <header>
        <h1>Page not found</h1>
        <p>{{ errorMessage }}</p>
        <RouterLink :to="{ name: 'home' }" class="button home">Go to Home</RouterLink>
      </header>
    </div>
  </main>
</template>

<style scoped>
.edit {
  padding: var(--padding-small);
  height: 38px;
  aspect-ratio: 1;
  border-radius: 2rem;
}

.edit,
form {
  margin-top: var(--margin-medium);
}

a.home {
  display: inline-flex;
  flex-flow: row nowrap;
  justify-content: center;
  align-items: center;
  gap: var(--gap-small);
}

.center {
  display: flex;
  flex-flow: column nowrap;
  align-items: center;
}
</style>
