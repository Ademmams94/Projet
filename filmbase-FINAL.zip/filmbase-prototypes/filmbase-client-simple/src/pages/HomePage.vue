<script setup>
import { ref, watch, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import FilmItem from '../components/FilmItem.vue';
import axios from 'axios';

const route = useRoute();
const router = useRouter();
const search = ref(route.query.search?.trim() || ''); // Recherche initiale
const films = ref([]); // Films trouvés
const loading = ref(false); // Indicateur de chargement
const error = ref(null); // Gestion des erreurs



// Liste de films locaux
const localFilms = [
  {
    name: "The Godfather Part II",
    year: 1974,
    image: new URL('@/assets/img/godfather.jpg', import.meta.url).href,
    description:
      "La jeunesse de Vito Corleone dans le New York des années 1920, tandis que son fils Michael consolide son emprise sur le syndicat du crime familial.",
  },
  {
    name: "12 Hommes en colère",
    year: 1957,
    image: new URL('@/assets/img/12angry.jpg', import.meta.url).href,
    description:
      "Un juré tente d'empêcher une erreur judiciaire en incitant ses collègues à réexaminer les preuves.",
  },
  {
    name: "Forrest Gump",
    year: 1994,
    image: new URL('@/assets/img/forrest.jpg', import.meta.url).href,
    description:
      "L'histoire de Forrest Gump, un homme avec un faible QI, et son influence accidentelle sur l'histoire tout en poursuivant son grand amour, Jenny.",
  },
  {
    name: "Inception",
    year: 2010,
    image: new URL('@/assets/img/inception.jpg', import.meta.url).href,
    description:
      "A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a CEO.",
  },
  {
    name: "Fight Club",
    year: 1999,
    image: new URL('@/assets/img/fightclub.jpg', import.meta.url).href,
    description:
      "An insomniac office worker and a soap maker form an underground fight club that evolves into something much, much more.",
  },
  {
    name: "The Matrix",
    year: 1999,
    image: new URL('@/assets/img/matrix.jpg', import.meta.url).href,
    description:
      "A hacker discovers from mysterious rebels about the true nature of his reality and his role in the war against its controllers.",
  },
  {
    name: "Seven Samurai",
    year: 1954,
    image: new URL('@/assets/img/sevensamurai.jpg', import.meta.url).href,
    description:
      "A poor village under attack by bandits recruits seven unemployed samurai to help them defend themselves.",
  },
  {
    name: "Pulp Fiction",
    year: 1994,
    image: new URL('@/assets/img/pulp.jpg', import.meta.url).href,
    description:
      "The lives of two mob hitmen, a boxer, a gangster's wife, and a pair of diner bandits intertwine in four tales of violence and redemption.",
  },
  {
    name: "The Good, the Bad and the Ugly",
    year: 1966,
    image: new URL('@/assets/img/thegood.jpg', import.meta.url).href,
    description:
      "A bounty hunting scam joins two men in an uneasy alliance against a third in a race to find a fortune in gold buried in a remote cemetery.",
  },
  {
    name: "The Shawshank Redemption",
    year: 1994,
    image: new URL('@/assets/img/theshawshank.jpg', import.meta.url).href,
    description:
      "Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.",
  },
  
];

// Film actuellement sélectionné (expandé)
const activeFilm = ref(null);

// Fonction pour basculer l'expansion d'une carte
function toggleCard(film) {
  console.log("Carte cliquée :", film.name); // Journal pour débogage
  activeFilm.value = activeFilm.value === film ? null : film;
  console.log("Film actif après clic :", activeFilm.value);
}

// Fonction pour rechercher des films via l'API backend
async function fetchFilms(query) {
  if (!query) {
    films.value = []; // Réinitialiser si aucune recherche
    return;
  }

  loading.value = true;
  error.value = null;

  try {
    const response = await axios.get('http://localhost:5001/api/films/search', {
      params: { q: query },
    });
    films.value = response.data;
  } catch (err) {
    console.error('Erreur lors de la recherche des films :', err.message);
    error.value = 'Une erreur est survenue lors de la recherche des films.';
  } finally {
    loading.value = false;
  }
}

// Gérer la soumission de la recherche
function handleSearchSubmit() {
  const query = search.value.trim();
  if (query) {
    router.push({ name: 'home', query: { search: query } });
  } else {
    router.push({ name: 'home' });
  }
}

// Rechercher les films à chaque changement d'URL
watch(
  () => route.query.search,
  (newSearch) => {
    search.value = newSearch?.trim() || '';
    fetchFilms(search.value);
  },
  { immediate: true }
);

onMounted(() => {
  fetchFilms(search.value);
});
</script>

<template>
  <main v-if="!search">
    <!-- Films locaux -->
    <div class="content">
      <div id="local-film-container">
        <div id="local-film-cards">
          <div
  class="local-film-card"
  v-for="film in localFilms"
  :key="film.name"
  :class="{ expanded: activeFilm === film }"
  @click="toggleCard(film)"
>
  <img :src="film.image" alt="Affiche du film" class="local-film-image" />
  <div class="local-film-info">
    <h2>{{ film.name }}</h2>
    <p>{{ film.year }}</p>
    <!-- Description affichée uniquement si la carte est active -->
    <p v-if="activeFilm === film" class="local-film-description">
      {{ film.description }}
    </p>
  </div>
</div>
        </div>
      </div>
    </div>
  </main>

  <main v-else id="main-list">
    <div class="content search-results">
      <!-- Barre de recherche -->
     

      <!-- Films trouvés -->
      <div v-if="loading">Chargement des films...</div>
      <ul v-else-if="films.length > 0">
        <li v-for="film in films" :key="film.id">
          <FilmItem :film="film" />
        </li>
      </ul>

      <div v-else-if="!loading && !error">Aucun film trouvé.</div>
      <div v-if="error" class="error-message">{{ error }}</div>
    </div>
  </main>
</template>


<style scoped>
/* Conteneur principal */
#local-film-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 20px;
}


#local-film-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 15px; /* Réduit l'espacement entre les cartes */
  width: 100%;
}

.local-film-card {
  background: #2d2d2d;
  border-radius: 8px;
  padding: 10px; /* Réduit l'espace intérieur */
  text-align: center;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  cursor: pointer;
}

.local-film-card:hover {
  transform: scale(1.03);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
}

.local-film-card.expanded {
  background: #3d3b3b;
  transform: scale(1.05);
}

.local-film-image {
  width: 100%;
  height: 180px; /* Ajuste la hauteur pour garder la cohérence */
  object-fit: contain; /* Affiche toute l'image sans la couper */
  border-radius: 8px;
}
.local-film-info h2 {
  font-size: 1rem; /* Réduit la taille du titre */
  margin: 8px 0;
  color: #fff;
}

.local-film-info p {
  font-size: 0.9rem; /* Réduit la taille des autres textes */
  color: #ccc;
  margin: 3px 0; /* Réduit l'espacement entre les paragraphes */
}

.local-film-description {
  margin-top: 8px; /* Réduit l'espacement au-dessus de la description */
  font-size: 0.8rem; /* Réduit encore la taille de la description */
  color: #aaa;
  line-height: 1.2; /* Diminue l'espacement entre les lignes */
}

/* Barre de recherche */
.search-results {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.search-input {
  width: 100%;
  max-width: 300px; /* Réduit la largeur maximale de la barre de recherche */
  padding: 8px; /* Réduit le padding de l'input */
  border: 1px solid var(--color-border);
  border-radius: 4px;
  margin-bottom: 15px; /* Réduit l'espacement en bas de la barre de recherche */
}

.error-message {
  color: red;
  font-size: 0.9rem; /* Réduit la taille du message d'erreur */
}

/* Responsiveness */
@media (min-width: 768px) {
  #local-film-cards {
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); /* Cartes légèrement plus grandes sur grand écran */
  }
}
</style>
