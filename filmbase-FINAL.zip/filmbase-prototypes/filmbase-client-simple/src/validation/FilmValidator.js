function validate(title, director, year, duration, description) {
  if (!title) {
    return 'Enter a title.'
  }

  if (!director) {
    return 'Enter a director.'
  }

  if (!Number.isInteger(year)) {
    return 'Enter a year.'
  }

  if (year < 1895) {
    return 'Enter a year no earlier than 1895.'
  }

  if (!Number.isInteger(duration)) {
    return 'Enter a duration.'
  }

  if (duration <= 0) {
    return 'Enter a duration greater than 0.'
  }

  if (!description) {
    return 'Enter a description.'
  }

  return null
}

export default { validate }
