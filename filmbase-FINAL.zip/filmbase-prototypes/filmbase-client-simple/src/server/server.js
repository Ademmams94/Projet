import express from "express";
import mysql from "mysql2";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import cors from "cors";

const app = express();
const PORT = process.env.PORT || 5001;

const corsOptions = {
  origin: "http://localhost:5173", // Adresse du front-end
  methods: ["GET", "POST", "PUT", "DELETE"],
  credentials: true, // Permet d'envoyer des cookies ou des en-têtes sécurisés
};

// Middleware
app.use(express.json());
app.use(cors(corsOptions));

// Configurer la connexion MySQL
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "film_library",
});

// Vérifier la connexion
db.connect((err) => {
  if (err) {
    console.error("Erreur de connexion à la base de données :", err);
    return;
  }
  console.log("Connecté à la base de données MySQL");
});

// Middleware pour vérifier le token JWT
const authenticateToken = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ message: "Accès non autorisé" });

  jwt.verify(token, "secret_key", (err, user) => {
    if (err) return res.status(403).json({ message: "Token invalide" });
    req.user = user; // Ajoute les données utilisateur dans la requête
    next();
  });
};

// Enregistrement d'un utilisateur
app.post("/api/register", async (req, res) => {
  const { username, email, password } = req.body;

  console.log("Données reçues :", req.body);

  try {
    const hashedPassword = await bcrypt.hash(password, 10);

    const query = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
    db.query(query, [username, email, hashedPassword], (err, result) => {
      if (err) {
        console.error("Erreur MySQL :", err.message);
        return res.status(500).json({ error: err.message });
      }
      res.status(201).json({ message: "Utilisateur enregistré avec succès" });
    });
  } catch (error) {
    console.error("Erreur :", error.message);
    res.status(500).json({ error: "Erreur lors de l'enregistrement de l'utilisateur" });
  }
});

// Connexion d'un utilisateur
app.post("/api/login", (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: "Tous les champs sont requis" });
  }

  const query = "SELECT * FROM users WHERE email = ?";
  db.query(query, [email], async (err, results) => {
    if (err) return res.status(500).json({ error: err.message });

    if (results.length === 0) {
      return res.status(401).json({ message: "Utilisateur non trouvé" });
    }

    const user = results[0];
    const isValidPassword = await bcrypt.compare(password, user.password);

    if (!isValidPassword) {
      return res.status(401).json({ message: "Mot de passe incorrect" });
    }

    const token = jwt.sign({ id: user.id, email: user.email }, "secret_key", {
      expiresIn: "1h",
    });

    res.json({ token, user: { id: user.id, username: user.username } });
  });
});

// Ajouter un film (protégé par JWT)
app.post("/api/films", authenticateToken, (req, res) => {
  console.log("Requête reçue :", req.body);
  console.log("Utilisateur authentifié :", req.user);

  const { title, director, year, duration, description } = req.body;
  const userId = req.user.id;

  if (!title || !director || !year || !duration || !description) {
    console.log("Validation échouée : champs manquants.");
    return res.status(400).json({ message: "Tous les champs sont requis" });
  }

  const query =
    "INSERT INTO films (title, director, year, duration, description, user_id) VALUES (?, ?, ?, ?, ?, ?)";
  db.query(
    query,
    [title, director, year, duration, description, userId],
    (err, result) => {
      if (err) {
        console.error("Erreur MySQL :", err.message);
        return res.status(500).json({ error: err.message });
      }
      console.log("Film ajouté :", result.insertId);
      res.status(201).json({ message: "Film ajouté avec succès", id: result.insertId });
    }
  );
});



// Rechercher des films par titre ou réalisateur
app.get("/api/films/search", (req, res) => {
  const query = req.query.q;

  if (!query) {
    return res.status(400).json({ message: "Le paramètre de recherche est requis." });
  }

  const searchQuery = `%${query}%`;

  const sqlQuery = `
    SELECT * FROM films 
    WHERE title LIKE ? OR director LIKE ?
  `;

  db.query(sqlQuery, [searchQuery, searchQuery], (err, results) => {
    if (err) {
      console.error("Erreur MySQL :", err.message);
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});
app.get("/api/films/:id", (req, res) => {
  const filmId = req.params.id;

  const query = "SELECT * FROM films WHERE id = ?";
  db.query(query, [filmId], (err, results) => {
    if (err) {
      console.error("Erreur MySQL :", err.message);
      return res.status(500).json({ error: "Erreur lors de la récupération du film." });
    }

    if (results.length === 0) {
      return res.status(404).json({ message: "Film non trouvé." });
    }

    res.json(results[0]); // Retourner le film correspondant
  });
});



app.delete("/api/films/:id", authenticateToken, (req, res) => {
  const filmId = req.params.id;
  const userId = req.user.id; // Utilisateur authentifié

  // Vérifier si le film appartient à l'utilisateur
  const query = "DELETE FROM films WHERE id = ? AND user_id = ?";
  db.query(query, [filmId, userId], (err, result) => {
    if (err) {
      console.error("Erreur MySQL :", err.message);
      return res.status(500).json({ error: "Erreur lors de la suppression du film." });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Film non trouvé ou non autorisé." });
    }

    res.json({ message: "Film supprimé avec succès." });
  });
});

// Mettre à jour un film (protégé par JWT)
app.put("/api/films/:id", authenticateToken, (req, res) => {
  const filmId = req.params.id;
  const { title, director, year, duration, description } = req.body;
  const userId = req.user.id;

  if (!title || !director || !year || !duration || !description) {
    return res.status(400).json({ message: "Tous les champs sont requis." });
  }

  const query = `
    UPDATE films
    SET title = ?, director = ?, year = ?, duration = ?, description = ?
    WHERE id = ? AND user_id = ?
  `;

  db.query(
    query,
    [title, director, year, duration, description, filmId, userId],
    (err, result) => {
      if (err) {
        console.error("Erreur MySQL :", err.message);
        return res.status(500).json({ error: "Erreur lors de la mise à jour du film." });
      }

      if (result.affectedRows === 0) {
        return res.status(404).json({ message: "Film non trouvé ou non autorisé." });
      }

      res.json({ message: "Film mis à jour avec succès." });
    }
  );
});


// Récupérer tous les films
app.get("/api/films", (req, res) => {
  const query = "SELECT * FROM films";
  db.query(query, (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

// Lancer le serveur
app.listen(PORT, () => {
  console.log(`Serveur backend démarré sur http://localhost:${PORT}`);
});
