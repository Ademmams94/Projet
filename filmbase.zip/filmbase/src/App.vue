<script setup>
import { RouterView } from 'vue-router'
import PageHeader from './components/PageHeader.vue'
import PageFooter from './components/PageFooter.vue'
</script>

<template>
  <PageHeader />
  <RouterView />
  <PageFooter />
</template>

<style>
#app > header,
#app > main,
#app > footer {
  padding: var(--padding-large);
}

#app > main {
  flex-grow: 1;
}

.content {
  max-width: var(--max-width);
  margin: 0 auto;
}

.app-logo * {
  font-size: 1.5rem;
  font-weight: bold;
  color: var(--color-heading);

  & a:link,
  a:visited {
    color: var(--color-heading);
  }
}
</style>
<style>
/* Ajoutez ces styles ou modifiez ceux existants */
html,
body {
  height: 100%; /* Pour que le conteneur parent occupe toute la hauteur */
  margin: 0;
}

#app {
  display: flex;
  flex-direction: column; /* Empile le header, le contenu et le footer verticalement */
  min-height: 100vh; /* S'assure que le conteneur occupe toute la hauteur de l'écran */
}

#app > header {
  padding: var(--padding-large);
}

#app > main {
  flex-grow: 1; /* Permet à la zone de contenu de s'étendre pour remplir l'espace disponible */
  padding: var(--padding-large);
}

#app > footer {
  padding: var(--padding-large);
}
</style>