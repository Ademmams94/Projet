<script setup></script>

<template>
  <main>
    <div class="content">
      <h1>About us</h1>
      <p>
        Nulla quis consectetur dui, vel lacinia nunc. In dictum, ex ut pretium faucibus, ligula ligula suscipit nunc, at
        faucibus justo elit id lectus. Suspendisse sagittis, tortor sed aliquam euismod, risus erat pharetra lacus,
        tristique efficitur sapien justo ac ante.
      </p>
      <p>
        Nulla ut posuere elit, vel cursus arcu. Nullam pellentesque arcu sollicitudin, porttitor dui eget, congue lorem.
        Ut sit amet facilisis orci. Integer placerat malesuada est ut tincidunt. Etiam semper auctor mauris, a aliquam
        est pulvinar a. Integer rhoncus gravida scelerisque. Etiam ac diam ultricies ante accumsan molestie et a lacus.
      </p>
      <p>
        Quisque ultricies blandit mi, nec bibendum urna egestas vitae. Suspendisse eleifend posuere scelerisque. Ut sit
        amet sodales nisi, in aliquam odio. Curabitur eget pellentesque quam, vitae rhoncus augue. Nulla non nibh
        consectetur, tempor urna sit amet, laoreet neque.
      </p>
      <p>
        Sed elementum, justo et convallis hendrerit, ante sem semper orci, eu mollis magna odio eget lorem. Aliquam
        mattis blandit nibh, sed tincidunt odio aliquam id.
      </p>
      <p>
        Nunc sit amet ullamcorper urna. Cras id diam ut nisi bibendum molestie. Ut eu sapien nunc. Nunc ac sagittis
        felis. Sed ultrices vulputate libero nec tincidunt. In sagittis bibendum nisi, id imperdiet lectus convallis et.
        Nulla convallis laoreet nibh. Nunc gravida eget ligula eleifend rhoncus. Ut quis laoreet dolor.
      </p>
    </div>
  </main>
</template>

<style scoped></style>
