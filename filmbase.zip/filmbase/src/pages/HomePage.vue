<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import WelcomeMessage from '../components/WelcomeMessage.vue'
import FilmItem from '../components/FilmItem.vue'
import useFilmService from '../services/FilmService.js'

const route = useRoute()
const filmService = useFilmService()

const search = computed(() => {
  return route.query.search?.trim()
})

const films = computed(() => {
  if (search.value) {
    return filmService.findFilms(search.value)
  }
  return []
})
</script>

<template>
  <main v-if="!search">
    <div class="content">
      <WelcomeMessage />
    </div>
  </main>

  <main v-else id="main-list">
    <div class="content search-results">
      <ul v-if="films.length > 0">
        <li v-for="film in films" :key="film.id">
          <FilmItem :film="film" />
        </li>
      </ul>

      <ul v-else>
        <li>No films were found matching "{{ search }}".</li>
      </ul>
    </div>
  </main>
</template>

<style scoped>
#main-list {
  padding: 0;
}

.search-results {
  display: flex;
  flex-flow: column nowrap;
  align-items: center;
}

ul {
  display: flex;
  flex-flow: column nowrap;
  justify-content: flex-start;
  align-items: stretch;
  width: 100%;
  list-style-type: none;
  padding-inline-start: 0;
}

li {
  padding: var(--padding-medium) var(--padding-large);
}

li:not(:last-child) {
  border-bottom: 1px solid var(--color-border);
}

@media (min-width: 768px) {
  #main-list {
    padding: 0 var(--padding-large);
  }

  ul {
    width: inherit;
    min-width: 512px;
  }

  li {
    padding-left: inherit;
    padding-right: inherit;
  }
}
</style>
