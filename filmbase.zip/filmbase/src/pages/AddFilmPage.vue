<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import FilmForm from '../components/FilmForm.vue'
import useFilmService from '../services/FilmService.js'
import validator from '../validation/FilmValidator.js'

const router = useRouter()
const filmService = useFilmService()

const errorMessage = ref('')

function addFilm(title, director, year, duration, description) {
  title = title.trim()
  director = director.trim()
  description = description.trim()

  const error = validator.validate(title, director, year, duration, description)

  if (!error) {
    const film = filmService.createFilm(title, director, Number.parseInt(year), Number.parseInt(duration), description)
    router.push({ name: 'film', params: { id: film.id } })
  } else {
    errorMessage.value = error
  }
}
</script>

<template>
  <main>
    <div class="content">
      <FilmForm
        primary-button="Add"
        primary-button-class="success"
        :error-message="errorMessage"
        @primary-button-clicked="addFilm"
      />
    </div>
  </main>
</template>
